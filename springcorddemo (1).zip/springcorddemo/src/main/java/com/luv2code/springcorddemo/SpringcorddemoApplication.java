package com.luv2code.springcorddemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringcorddemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringcorddemoApplication.class, args);
	}

}
