package com.luv2code.springcorddemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringcorddemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
